from django.db import models

class Alunos(models.Model):
    nome = models.CharField(max_length=50)
    cpf = models.CharField(max_length=50)

    def __str__(self):
        return f"Nome: {self.nome}, CPF: {self.cpf}"

class Definir_Setor(models.Model):
    setor = models.CharField(max_length=50)

    def __str__(self):
        return f"Definir setores: {self.setor}"

class Definir_Escala(models.Model):
    data = models.DateField()
    setor = models.ForeignKey(Definir_Setor, on_delete=models.CASCADE)  # Chave estrangeira para a classe Setor
    horario = models.TimeField()
    aluno = models.ForeignKey(Alunos, on_delete=models.CASCADE)  # Chave estrangeira para a classe aluno

    def __str__(self):
        return f"Designar data de escala: {self.data}, Setor: {self.setor}, Horário: {self.horario}"
    
class Responsavel_Setor(models.Model):
    TIPO_CHOICES = [
        ('docente', 'Docente'),
        ('discente', 'Discente'),
        ('outro', 'Outro'),
    ]

    setor = models.ForeignKey(Definir_Setor, on_delete=models.CASCADE)
    tipo = models.CharField(max_length=10, choices=TIPO_CHOICES, default='outro')
    nome_responsavel = models.CharField(max_length=50, blank=True, null=True)
    cpf_responsavel = models.CharField(max_length=50, blank=True, null=True)
    aluno = models.ForeignKey(Alunos, on_delete=models.CASCADE, blank=True, null=True, related_name='responsaveis')

    def __str__(self):
        return f"Responsável: {self.nome_responsavel}, Tipo: {self.tipo}, Setor: {self.setor}"
    
class VisualizarEscala(models.Model):
    escala = models.ForeignKey(Definir_Escala, on_delete=models.CASCADE)
    aluno = models.ForeignKey(Alunos, on_delete=models.CASCADE)
    responsavel = models.ForeignKey(Responsavel_Setor, on_delete=models.CASCADE)
    horario = models.TimeField()
    setor = models.ForeignKey(Definir_Setor, on_delete=models.CASCADE)

    def __str__(self):
        return f"Escala: {self.escala}, Aluno: {self.aluno}, Responsável: {self.responsavel}, Horário: {self.horario}, Setor: {self.setor}"