from django.contrib import admin
from app.models import * 

admin.site.register(Alunos)
admin.site.register(Definir_Setor)
admin.site.register(Definir_Escala)
admin.site.register(Responsavel_Setor)
admin.site.register(VisualizarEscala)